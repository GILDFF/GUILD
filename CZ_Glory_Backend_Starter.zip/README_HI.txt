CZ GLORY BACKEND — STARTER

Bhai, ye safe backend starter hai. Isse abhi real Guild Glory launch nahi hoga.
Official FFGlory API ka exact server URL, endpoint paths aur request format zaroori hain.

SABSE PEHLE SECURITY:
1. Aapne API key chat mein share ki thi. FFGlory dashboard par jaakar use REGENERATE /
   REFRESH karo. Purani key ko compromised samjho.
2. Nayi key chat, HTML, screenshot ya public GitHub mein mat bhejna.
3. Nayi key sirf server ki .env file mein rakho.

SETUP (computer ya hosting par):
1. Node.js 18 ya newer install karo.
2. Is folder mein terminal kholo aur `npm install` chalao.
3. `.env.example` ki copy `.env` naam se banao.
4. Official FFGlory docs se exact values lekar .env fill karo:
   FFGLORY_API_BASE, FFGLORY_API_KEY aur *_PATH values.
5. `npm start` chalao.
6. `/health` kholkar server test karo.

IMPORTANT:
- Aapke HTML ka Backend URL field isi server ka public HTTPS address maangta hai.
- Backend ko hosting par deploy karna hoga; main aapke hosting account mein khud deploy nahi kar sakta.
- Official endpoint details ke bina API routes 501 return karenge. Ye jaan-boojhkar hai;
  galat ya fake API calls nahi bheji jaayengi.
- Production mein browser ke HTML mein master API key mat rakho; key server ke .env mein hi rahe.
- Aapke HTML ka localStorage login/credits/coupons demo-only hain, secure production database nahi.
