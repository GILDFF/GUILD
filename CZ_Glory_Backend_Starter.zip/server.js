const express = require("express");
const helmet = require("helmet");
const rateLimit = require("express-rate-limit");
require("dotenv").config();

const app = express();
app.use(helmet());
app.use(express.json({ limit: "20kb" }));
app.use(rateLimit({ windowMs: 60_000, limit: 60 }));

const PORT = process.env.PORT || 3000;
const API_BASE = (process.env.FFGLORY_API_BASE || "").replace(/\/$/, "");
const API_KEY = process.env.FFGLORY_API_KEY || "";

app.get("/health", (_req, res) =>
  res.json({ ok: true, service: "CZ Glory backend", mode: "starter" })
);

// Upstream paths are intentionally not guessed. Use exact paths from official docs.
const routes = [
  ["get", "/api/ffglory/me", "ME_PATH"],
  ["get", "/api/ffglory/pricing", "PRICING_PATH"],
  ["get", "/api/ffglory/groups", "GROUPS_PATH"],
  ["post", "/api/ffglory/launch", "LAUNCH_PATH"],
  ["post", "/api/ffglory/group-action", "GROUP_ACTION_PATH"]
];

async function proxy(req, res, envName) {
  const upstreamPath = process.env[envName];
  if (!API_BASE || !API_KEY || !upstreamPath) {
    return res.status(501).json({
      error: "Official FFGlory API settings are incomplete.",
      missing: [
        ...(!API_BASE ? ["FFGLORY_API_BASE"] : []),
        ...(!API_KEY ? ["FFGLORY_API_KEY"] : []),
        ...(!upstreamPath ? [envName] : [])
      ]
    });
  }
  try {
    const response = await fetch(new URL(upstreamPath, API_BASE), {
      method: req.method,
      headers: {
        Authorization: `Bearer ${API_KEY}`,
        "Content-Type": "application/json",
        Accept: "application/json"
      },
      ...(req.method === "POST" ? { body: JSON.stringify(req.body || {}) } : {})
    });
    const body = await response.text();
    res.status(response.status)
      .type(response.headers.get("content-type") || "application/json")
      .send(body);
  } catch {
    res.status(502).json({ error: "Could not reach configured FFGlory API server." });
  }
}

for (const [method, path, envName] of routes) {
  app[method](path, (req, res) => proxy(req, res, envName));
}

app.listen(PORT, () => console.log(`CZ Glory backend listening on ${PORT}`));
